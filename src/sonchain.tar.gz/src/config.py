#!/usr/bin/env python3

# -*- coding: utf-8 -*-

VERSION = "4.0.0"
REPO_OWNER = "kalilovers"
REPO_NAME = "sonchain"
INSTALL_DIR = "/opt/sonchain"
RELEASE_API_URL = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/releases/latest"