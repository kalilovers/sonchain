 ### Sonchain v4.0.0 Release Notes (Summary)


</br>


**What's New:**

 - Added Psiphon with control management .
 - Added the ability to synchronize Socksify and ProxyChains with Psiphon.
 - Added connection test to the Tor status menu (shows IP, Region and test service).



**Bug Fixes:**

 - Some issues were fixed.


**Enhancements:**

 - Better management when installing packages
 - Some technical improvements
 - Minor improvement in UI

